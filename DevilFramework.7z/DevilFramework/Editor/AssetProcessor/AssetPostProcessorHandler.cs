﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace DevilEditor
{
    public class AssetPostProcessorHandler : AssetPostprocessor
    {
        static void OnPostprocessAllAssets(string[] assets, string[] deletedAssets, string[] movedAssets, string[] movedFramAssetPaths)
        {
        }
    }
}