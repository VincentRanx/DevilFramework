﻿using UnityEngine;
using UnityEngine.UI;

namespace Devil
{
    public class UIEventMask : Graphic
    {
        protected override void UpdateGeometry()
        {
        }

        protected override void UpdateMaterial()
        {
        }

        public override void Rebuild(CanvasUpdate update)
        {
        }

        protected override void OnPopulateMesh(VertexHelper vh)
        {
        }
    }
}