﻿#define TEST
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Devil.Utility
{
    public class AvlTree<T> : ICollection<T>
    {
        Node mRoot;

        public int Count { get { return mRoot == null ? 0 : mRoot.count; } }
        public int Deep { get { return mRoot == null ? 0 : mRoot.deep; } }
        public bool IsReadOnly { get { return false; } }
        IdentifierDelegate<T> mIdentifier;

        public AvlTree(IdentifierDelegate<T> identifier = null)
        {
            if (identifier == null)
                mIdentifier = (x) => x == null ? 0 : x.GetHashCode();
            else
                mIdentifier = identifier;
        }

        public void Add(T item)
        {
            var id = mIdentifier(item);
            var newnode = new Node(id, item);
            if (mRoot == null)
            {
                mRoot = newnode;
            }
            else
            {
                var node = mRoot;
                while (node != null)
                {
                    if(node.id == id)
                    {
#if TEST
                        RTLog.LogErrorFormat(LogCat.Game, "The AVL tree don't support the same value({0}) to be added.", item);
#endif
                        return;
                    }
                    else if (node.id > id)
                    {
                        if(node.left == null)
                        {
                            node.AddLeftLeaf(newnode);
                            node.UpdateTree();
                            if (node.parent != null)
                                node.parent.FixBalence();
                            break;
                        }
                        else
                        {
                            node = node.left;
                        }
                    }
                    else
                    {
                        if(node.right == null)
                        {
                            node.AddRightLeaf(newnode);
                            node.UpdateTree();
                            if (node.parent != null)
                                node.parent.FixBalence();
                            break;
                        }
                        else
                        {
                            node = node.right;
                        }
                    }
                }
                while (mRoot.parent != null)
                    mRoot = mRoot.parent;
            }
        }

        public void Clear()
        {
            mRoot = null;
        }

        public bool ContainsId(int id)
        {
            var node = mRoot;
            while(node != null)
            {
                if (node.id == id)
                    return true;
                else if (node.id < id)
                    node = node.right;
                else
                    node = node.left;
            }
            return false;
        }

        public bool Contains(T item)
        {
            return ContainsId(mIdentifier(item));
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            var iter = GetEnumerator();
            for (int i = arrayIndex; i < array.Length; i++)
            {
                if (iter.MoveNext())
                    array[i] = iter.Current;
                else
                    break;
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new Enumerator(this);
        }

        public bool Remove(T item)
        {
            throw new System.NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public string GetInfo(int start, int end)
        {
            var buff = StringUtil.GetBuilder();
            buff.Append("AVL[Count:").Append(Count).Append(", Deep:").Append(Deep).Append(", Root:")
                .Append(mRoot == null ? " " : mRoot.id.ToString()).Append("]");
            var node = mRoot;
            Stack<Node> stack = new Stack<Node>();
            while(node != null)
            {
                if(node.id == start)
                {
                    stack.Push(node);
                    break;
                }
                else if(node.id > start)
                {
                    stack.Push(node);
                    node = node.left;
                }
                else
                {
                    node = node.right;
                    break;
                }
            }
            int n = 0;
            while(stack.Count > 0)
            {
                node = stack.Pop();
                if (node.id > end)
                    break;
                buff.Append("\n [").Append(n++).Append("] ").Append(node);
                node = node.right;
                while(node != null)
                {
                    stack.Push(node);
                    node = node.left;
                }
            }
            return StringUtil.ReleaseBuilder(buff);
        }

#if TEST
        public override string ToString()
        {
            return GetInfo(0, 128);
        }
#endif

        internal class Node
        {
            public T value;
            public Node left;
            public Node right;
            public Node parent;

            public int id; // id
            public int deep; // 深度
            public int count; // 节点数

            public Node(int id, T value)
            {
                this.value = value;
                this.id = id;
                deep = 1;
                count = 1;
            }

            public int BalenceFactor
            {
                get
                {
                    int l = left == null ? 0 : left.deep;
                    int r = right == null ? 0 : right.deep;
                    return l - r;
                }
            }

            public void FixBalence()
            {
                var node = this;
                while(node != null)
                {
                    var balence = node.BalenceFactor;
                    // 左旋转
                    if (balence < -1)
                    {
                        var r = node.right;
                        if (r.BalenceFactor > 0)
                        {
                            r.RotateRight();
                            r.UpdateSelf();
                        }
                        node.RotateLeft();
                        node.UpdateTree();
                        break;
                    }
                    else if (balence > 1)
                    {
                        var l = node.left;
                        if (l.BalenceFactor < 0)
                        {
                            l.RotateLeft();
                            l.UpdateSelf();
                        }
                        node.RotateRight();
                        node.UpdateTree();
                        break;
                    }
                    else
                    {
                        node = node.parent;
                    }
                }
            }

            public void AddLeftLeaf(Node newnode)
            {
                left = newnode;
                newnode.parent = this;
                deep = Mathf.Max(newnode.deep, right == null ? 0 : right.deep) + 1;
                count = newnode.count + (right == null ? 0 : right.count) + 1;
            }

            public void AddRightLeaf(Node newnode)
            {
                right = newnode;
                newnode.parent = this;
            }

            public void UpdateSelf()
            {
                deep = Mathf.Max(left == null ? 0 : left.deep, right == null ? 0 : right.deep) + 1;
                count = (left == null ? 0 : left.count) +
                    (right == null ? 0 : right.count) + 1;
            }

            public void UpdateTree()
            {
                var p = this;
                while (p != null)
                {
                    p.UpdateSelf();
                    p = p.parent;
                }
            }

            // 左旋转
            public void RotateLeft()
            {
                var p = parent;
                var rl = right.left;
                right.parent = p;
                if(p != null)
                {
                    if (p.left == this)
                        p.left = right;
                    else
                        p.right = right;
                }
                parent = right;
                right.left = this;
                right = rl;
                if (rl != null)
                    rl.parent = this;
            }

            // 右旋转
            public void RotateRight()
            {
                var p = parent;
                var lr = left.right;
                left.parent = p;
                if(p != null)
                {
                    if (p.left == this)
                        p.left = left;
                    else
                        p.right = left;
                }
                parent = left;
                left.right = this;
                left = lr;
                if (lr != null)
                    lr.parent = this;
            }

#if TEST
            public override string ToString()
            {
                // "value" (AVL_NODE[P:p, L:r, R:r] deep:d balence:b count:c)
                //var buf = StringUtil.GetBuilder();
                //buf.Append("(AVL_NODE[P:").Append(parent == null ? " " : parent.id.ToString());
                //buf.Append(", L:").Append(left == null?" ":left.id.ToString());
                //buf.Append(", R:").Append(right == null ? " " : right.id.ToString());
                //buf.Append("] deep:").Append(deep).Append(" balence:").Append(BalenceFactor).Append(" count:").Append(count).Append(")");
                //buf.Append("  \"").Append(value).Append("\"");
                //return StringUtil.ReleaseBuilder(buf);
                return string.Format("Avl[P:{0}\t L:{1}\t R:{2}\t deep:{3}\t balence:{4}\t count:{5}]\t  \"{6}\"",
                    parent == null ? "-" : parent.id.ToString(),
                    left == null ? "-" : left.id.ToString(),
                    right == null ? "-" : right.id.ToString(),
                    deep.ToString(),
                    BalenceFactor.ToString(),
                    count.ToString(),
                    value.ToString());
            }
#endif

        }
        
        internal class Enumerator : IEnumerator<T>
        {
            AvlTree<T> avl;
            Node current;
            Stack<Node> visitStack; //

            public T Current { get { return current == null ? default(T) : current.value; } }

            object IEnumerator.Current { get { return Current; } }

            public Enumerator(AvlTree<T> avl)
            {
                this.avl = avl;
                if (avl != null)
                    visitStack = new Stack<Node>(avl.Deep);
                Reset();
            }

            public void Dispose()
            {
                avl = null;
                current = null;
            }

            public bool MoveNext()
            {
                if (visitStack == null || visitStack.Count == 0)
                    return false;
                current = visitStack.Pop();
                if (current != null)
                {
                    var node = current.right;
                    while (node != null)
                    {
                        visitStack.Push(node);
                        node = node.left;
                    }
                }
                return current != null;
            }

            public void Reset()
            {
                if (visitStack != null)
                {
                    visitStack.Clear();
                    var node = avl.mRoot;
                    while (node != null)
                    {
                        visitStack.Push(node);
                        node = node.left;
                    }
                }
            }
        }
    }
}