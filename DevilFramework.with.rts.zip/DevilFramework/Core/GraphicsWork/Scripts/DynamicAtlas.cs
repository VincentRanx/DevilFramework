﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DynamicAtlas
{
    public DynamicAtlas(int width, int height)
    {

    }
}
